/*
 * File:   main.c
 * Author: Ceyhun Pempeci
 *
 * Created on January 9, 2025, 9:25 AM
 */


#include "CONFIG.h"

#define _XTAL_FREQ 64000000


void main(void) {
    
    
    TRISD0 = 0; //D0 is in output mode
    
    while(1)
    {
        LATD0 = 1;
        __delay_ms(500);
        LATD0 = 0;
        __delay_ms(500);
    }
    
    
    return;
}
